import ray.data as raydata
import pandas as pd

data = raydata.read_csv('tests/target.csv')
dataset = data.add_column("gd", lambda df: pd.qcut(df['generic_score'], 10, labels=False) + 1)
dataset.write_csv('tests/target_decile.csv')