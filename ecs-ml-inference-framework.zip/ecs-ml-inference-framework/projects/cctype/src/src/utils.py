import boto3
import numpy as np
import pandas as pd


def read_file(file_path):
    if file_path.startswith("s3"):
        s3 = boto3.resource("s3")
        bucket, key = file_path.replace("s3://", "").split("/", 1)
        return s3.Bucket(bucket).Object(key).get()['Body']
    else:
        return open(file_path, 'rb')


def prepare_input(df, model_columns, numerical, categorical):
    # add state, age/year born
    # Selects highest TVD features and other select important categorical features to use in model
    one_hot_columns = list(categorical)
    for i in ['currstate', 'g_zip_locality', 'i_occupation_cd', 'i_gender_cd']:
        if i not in one_hot_columns:
            one_hot_columns.append(i)
    for i in ['county_name', 'state_code', 'currzipcode']:
        if i in one_hot_columns:
            one_hot_columns.remove(i)
    one_hot_df = df[one_hot_columns]
    one_hot_df = pd.get_dummies(one_hot_df, columns=one_hot_columns)
    one_hot_df.head()
    df = df.join(one_hot_df)
    for col in model_columns:
        if col not in df.columns:
            df[col] = False
    df = df[model_columns]
    return df