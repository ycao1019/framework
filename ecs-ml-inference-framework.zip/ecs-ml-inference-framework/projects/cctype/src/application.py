from mlflow.pyfunc import PythonModel
import pickle
from ecs.utils import load_manifest
from src.utils import *

from ecs.inference.modelloader import BaseApplication
import os
import json

class Application(BaseApplication):

    # implementing abstract method
    def load_model(self):
        '''
        self.input_params: dict from manifest.json -> input_params
        self.meta_info: dict from manifest.json -> meta_info
        self.models_path: directory where the model artifacts are saved

        Please add your custom logic here to load the model artifacts, e.g.
        self.model = joblib.load(f'{self.models_path}/model.pkl')
        '''
        self.models={}
        for k in self.input_params["model_files"]:
            self.models[k] = {}
            self.models[k]["model"] = pickle.load(
                read_file(f'{self.models_path}/{k}/{self.input_params["model_files"][k]["model"]}'))[0]

        source_path = os.environ["SOURCE_PATH"].rstrip("/")
        columns_config_file = os.path.join("/".join(source_path.split("/")[0:-1]), "config", "columns.json")
        self.columns_config = json.load(read_file(columns_config_file))


    # implementing abstract method
    def make_prediction(self, payload):
        data = payload
        data.fillna(np.nan, inplace=True)
        result = dict()
        if "id_column" in self.input_params:
            result[self.input_params["id_column"]] = data[self.input_params["id_column"]].values
        for model in self.input_params["models_seq"]:
            filtered_data = prepare_input(data,
                                          self.input_params["columns_in_use"][model],
                                          self.columns_config["numerical"],
                                          self.columns_config["categorical"])
            pred_score = self.models[model]["model"].predict_proba(filtered_data)[:, 1]
            result[f"{model}_score"] = pred_score
        res = pd.DataFrame(result)
        return res


class GlobalProcessor:

    from ray.data import Dataset
    import pandas as pd

    @classmethod
    def postprocess_pandas(cls, dataset: pd.DataFrame, input_params: dict = None) -> pd.DataFrame:
        model_names = input_params['models_seq']
        for model in model_names:
            dataset[f"{model}_decile"] = pd.qcut(dataset[f"{model}_score"], 10, labels=False) + 1
        return dataset