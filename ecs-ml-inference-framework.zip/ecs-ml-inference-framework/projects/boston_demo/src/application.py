from ecs.inference.modelloader import BaseApplication
import xgboost as xgb
import joblib

class Application(BaseApplication):

    # implementing abstract method
    def load_model(self):
        '''
        self.input_params: dict from manifest.json -> input_params
        self.meta_info: dict from manifest.json -> meta_info
        self.models_path: directory where the model artifacts are saved

        Please add your custom logic here to load the model artifacts, e.g.
        self.model = joblib.load(f'{models_path}/model.pkl')
        '''
        self.input_transformer = joblib.load(f'{self.models_path}/input_transformer.pkl')
        self.model = xgb.XGBRegressor()
        self.model.load_model(f'{self.models_path}/model.xgb')
        self.output_transformer = joblib.load(f'{self.models_path}/output_transformer.pkl')

      
    # implementing abstract method
    def make_prediction(self, payload):
        payload = self.input_transformer.transform(payload)
        payload = self.model.predict(payload)
        return self.output_transformer.transform(payload)   



    