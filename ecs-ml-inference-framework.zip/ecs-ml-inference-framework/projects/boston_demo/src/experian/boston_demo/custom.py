import numpy as np
from sklearn.base import TransformerMixin


class StringTypeBinTransformer(TransformerMixin):
    def __init__(self, bins, labels):
        self.bins = bins
        self.labels = labels
    
    def transform(self, X):
        inds = np.digitize(X, self.bins)
        get_labels = np.vectorize(lambda v: self.labels[v])
        return get_labels(inds)