import argparse
from ecs.inference.manifest import SourceFileFormats, ResultFileFormats
from ecs.utils import load_manifest
import ray
from ray.job_submission import JobSubmissionClient, JobStatus
import time

if __name__ == "__main__":
    argParser = argparse.ArgumentParser()
    argParser.add_argument( "--project", type=str, required=False, help="ray endpoint")
    argParser.add_argument( "--endpoint", type=str, required=False, help="ray endpoint")
    argParser.add_argument( "--sourcepath", type=str, required=True, help="file location; can be a local folder/file or S3 path")
    argParser.add_argument( "--sourceformat", type=SourceFileFormats, required=True, help="choose one from the following: ['csv', 'parquet', 'json', 'numpy', 'text', 'image']")
    argParser.add_argument("--resultpath", type=str, required=True, help="where to save the output")
    argParser.add_argument("--resultformat", type=ResultFileFormats, required=True, help="choose one from the following: ['csv', 'parquet', 'json', 'numpy']")
    args = argParser.parse_args()

    mf = load_manifest(f'./projects/{args.project}/manifest.json')
    if not args.endpoint:
        ray.init()
    client = JobSubmissionClient(args.endpoint)

    job_id = client.submit_job(
        # Entrypoint shell command to execute
        entrypoint=f'python -m ecs.inference.jobmanager --sourcepath {args.sourcepath} --resultpath {args.resultpath} --sourceformat {args.sourceformat} --resultformat {args.resultformat}',
        # inject runtime env
        runtime_env={"env_vars": mf.deploy_config.env_vars}
    )
    print(job_id)

    def wait_until_status(job_id, status_to_wait_for, timeout_seconds=5):
        start = time.time()
        while time.time() - start <= timeout_seconds:
            status = client.get_job_status(job_id)
            print(f"status: {status}")
            if status in status_to_wait_for:
                break
            time.sleep(1)


    wait_until_status(job_id, {JobStatus.SUCCEEDED, JobStatus.STOPPED, JobStatus.FAILED})
    logs = client.get_job_logs(job_id)
    print(logs)
 