import json
import argparse
import os.path as path


TEMPLATE_FILES = {
    'local': './templates/raycluster-template-local.yml',
    'cloud': './templates/raycluster-template.yml'
}

def get_command_parser():
    """Returns command parser

    :return:
    """
    parser = argparse.ArgumentParser(description='Generate model specific deployment json file')
    parser.add_argument('--project', type=str, required=True)
    parser.add_argument('--env', type=str, required=False, default="cloud")

    return parser

def main(args):
    relative_path = path.dirname(path.realpath(__file__))
    template_path = TEMPLATE_FILES[args.env]
    manifest_path = f'./projects/{args.project}/manifest.json'
    deploy_file_path = relative_path

    """
    if not validate_file_path(relative_path, template_path):
        raise Exception(f'the file path for --template arg should be under the same dir or subdir of gendeployfile.py')
    if not validate_file_path(relative_path, manifest_path):
        raise Exception(f'the file path for --manifest arg should be under the same dir or subdir of gendeployfile.py')
    if not validate_file_path(relative_path, deploy_file_path):
        raise Exception(f'the file path for --target arg should be under the same dir or subdir of gendeployfile.py')
    """
    
    with open(template_path, 'r') as ft:
        template = ft.read()
        with open(manifest_path, 'r') as fc:
            manifest = json.load(fc)['deploy_config']
            manifest['image'] = manifest["project_name"]
            for key in manifest.keys():
                template = template.replace('{{'+ key +'}}', str(manifest[key]))
    print('------------------Start of Deploy.json--------------------')
    print(template)
    print('-------------------End of Deploy.json---------------------')
    with open(f'{deploy_file_path}/ray-cluster-deploy.yml', "w") as target:
        target.write(template)

"""
def validate_file_path(relative_path, file_to_check):

    fpath = path.dirname(path.realpath(file_to_check))
    if fpath.startswith(relative_path):
        return True
    return False
"""
    

if __name__ == "__main__":
    parser = get_command_parser()
    args = parser.parse_args()
    main(args)