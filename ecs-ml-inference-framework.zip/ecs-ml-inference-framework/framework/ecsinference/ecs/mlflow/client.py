from mlflow.tracking.client import MlflowClient
import mlflow
from ecs.utils import change_folder_name, is_folder, files_merge, file_decompress, delete_folder
import timeout_decorator
import pandas as pd
from datetime import datetime
import os

MLFLOW_MODEL_FOLDER = "mlflow_model"

def format_registed_model(model):
    model_view = {}
    model_view['name'] = model.name
    model_view['description'] = model.description
    model_view['tags'] = model.tags
    model_view['creation_timestamp'] = datetime.fromtimestamp(model.creation_timestamp//1000)
    model_view['update_timestamp'] = datetime.fromtimestamp(model.last_updated_timestamp//1000)
    if model.latest_versions:
        model_view['latest_version']=model.latest_versions[0].version
        model_view['latest_version_run_id']=model.latest_versions[0].run_id
        model_view['latest_version_source']=model.latest_versions[0].source
        model_view['latest_version_status']=model.latest_versions[0].status
        model_view['latest_version_stage']=model.latest_versions[0].current_stage
        model_view['latest_version_desc']=model.latest_versions[0].description
        # model_view['latest_version_user_id']=model.latest_versions[0].user_id
    return model_view



class Client:

    @timeout_decorator.timeout(10)
    def __init__(self, mlflow_url = None):
        if mlflow_url is None:
            mlflow_url = os.environ["MLFLOW_TRACKING_URL"]
        print(f'server url: {mlflow_url}')
        mlflow.set_tracking_uri(mlflow_url)
        self.mlfclient = MlflowClient()


    def find_registered_model(self, name: str, version: int = -1) -> dict:
        if version == -1: # get the latest model
            return dict(self.mlfclient.get_registered_model(name))
        else:
            model_versions = self.mlfclient.search_model_versions(f"name='{name}'")
            for mv in model_versions:
                mv = dict(mv)
                ver = int(mv['version'])
                if ver == version:
                    return mv
        return None

    def get_artifact_uri(self, name: str, version: int = -1) -> str:
        model = self.find_registered_model(name, version)
        if model is None:
            return None
        return model['source']


    def get_run_id(self, name: str, version: int = -1) -> str:
        model = self.find_registered_model(name, version)
        if model is None:
            return None
        return model['run_id']

    def download_artifacts(self, dst_path: str, name: str, version: str = -1) -> bool:
        target = None
        model = self.find_registered_model(name, version)
        if model:
            source = model['source']
            if source:
                delete_folder(os.path.join(dst_path, MLFLOW_MODEL_FOLDER))
                target = mlflow.artifacts.download_artifacts(artifact_uri=source, dst_path=dst_path)
                if target:
                    change_folder_name(target, MLFLOW_MODEL_FOLDER)
                    fragment_folder = os.path.join(dst_path, MLFLOW_MODEL_FOLDER,'artifacts','fragments')
                    tmp_file = os.path.join(dst_path, MLFLOW_MODEL_FOLDER, 'tmp','models.zip')
                    model_folder = os.path.join(dst_path, MLFLOW_MODEL_FOLDER, 'artifacts', 'models')
                    if is_folder(fragment_folder):
                        files_merge(fragment_folder, tmp_file)
                        file_decompress(tmp_file, model_folder)
                        delete_folder(fragment_folder)
                        delete_folder(os.path.join(dst_path, MLFLOW_MODEL_FOLDER, 'tmp'))
        else:
            print('model not found')
        return target is not None
    
    
    def list_registered_models(self, format = "dict"):
        models = self.mlfclient.search_registered_models()
        models_view = [format_registed_model(model) for model in models]
        if format =="df":
            return pd.DataFrame(models_view)
        return models_view


    def update_model_description(self, name: str, description: str):
        self.mlfclient.update_registered_model(name, description)


    def set_model_tag(self, name: str, key: str, value: str):
        self.mlfclient.set_registered_model_tag(name, key, value)


    def delete_model_tag(self, name: str, key: str):
        self.mlfclient.delete_registered_model_tag(name, key)




    def list_model_versions(self, name: str, format = "dict"):
        mvs = self.mlfclient.search_model_versions(f"name='{name}'")
        mvs = [dict(mv) for mv in mvs]
        if format =="df":
            return pd.DataFrame(mvs)
        return mvs
    

    def update_mv_description(self, name: str, version: str, description: str):
        self.mlfclient.update_model_version(name, version, description)


    def set_mv_tag(self, name: str, version: str, key: str, value: str):
        self.mlfclient.set_model_version_tag(name, version, key, value)


    def delete_mv_tag(self, name: str, version: str, key: str):
        self.mlfclient.delete_model_version_tag(name, version, key)

    def get_run(self, run_id: str):
        return self.mlfclient.get_run(run_id)