import argparse
from ecs.mlflow import Client
import sys

if __name__ == "__main__":
    argParser = argparse.ArgumentParser()
    argParser.add_argument( "--buildpath", type=str, required=True, help="location to host the mlflow artifacts")
    argParser.add_argument( "--mlflowserver", type=str, required=True, help="mlflow server url")
    argParser.add_argument("--modelname", type=str, required=True, help="model name registered in mlflow server")
    argParser.add_argument("--version", type=int, default=-1, help="model version; if absent, the latest version will be used")
    args = argParser.parse_args()
    print(args)
    client = Client(args.mlflowserver)
    success = client.download_artifacts(args.buildpath, args.modelname, args.version)
    
    if not success:
        print("failure")
        sys.exit(1)
    print("success")