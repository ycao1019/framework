import argparse
import os

import ray
import ray.data
from ray.air import Checkpoint
from ray.train.batch_predictor import BatchPredictor

from .predictor import BasePredictor
import ecs.inference.manifest as manifest
from ecs.utils import load_module, load_object, load_manifest


FILE_READERS = {
    'csv': ray.data.read_csv,
    'parquet': ray.data.read_parquet,
    'json': ray.data.read_json,
    'numpy': ray.data.read_numpy,
    'text': ray.data.read_text,
    'image': ray.data.read_images
}

FILE_WRITERS = {
    'csv': 'write_csv',
    'parquet': 'write_parquet',
    'json': 'write_json',
    'numpy': 'write_numpy'
}

def start_job(sourcepath: str, resultpath: str, sourceformat: manifest.SourceFileFormats, resultformat: manifest.ResultFileFormats, suppresswarnings=False) -> None:
    """
    This is the function invoked by job submission from the client.
    Parameters
    ----------
    sourcepath: str :
        it can be a local or cloud folder (like s3), if there are multiple files to consume; or a file path if all data in one file (only for experiments, better use multiple files in production)    
    resultpath: str :
        the path to save the results
    sourceformat :
        (Default value = 'parquet', accept ['csv', 'parquet', 'json', 'numpy', 'text', 'image'])
    resultformat :
         (Default value = 'parquet', accept ['csv', 'parquet', 'json', 'numpy'])

    Returns
    -------
        None
    """
    model_dir = os.environ['MODEL_DIR']
    predictor = BatchPredictor(
        checkpoint=Checkpoint.from_dict({'MODEL_DIR':model_dir, "SUPPRESS_WARNINGS": suppresswarnings}),
        predictor_cls=BasePredictor
    )

    # load global processor
    try:
        import sys
        custom_code_path = os.path.join(model_dir, 'code')
        if os.path.exists(custom_code_path) and custom_code_path not in sys.path:
            sys.path.append(custom_code_path)
        global_processor = load_object(load_module("application"), "GlobalProcessor")
    except Exception as error:
        global_processor = None
    
    input_params = None
    if global_processor:
        manifest = load_manifest(os.path.join(model_dir, 'artifacts/manifest.json'))
        input_params = manifest.input_params
    # read data into ray.data.DataSet
    data = FILE_READERS[sourceformat](sourcepath)
    
    # preprocess
    if global_processor and hasattr(global_processor, 'preprocess_raydata'):
        data = global_processor.preprocess_raydata(data, input_params)
    if global_processor and hasattr(global_processor, 'preprocess_pandas'):
        data_size = data.count()
        data = global_processor.preprocess_pandas(data.to_pandas(limit=data_size), input_params)
        data = ray.data.from_pandas(data)

    # predict
    results = predictor.predict(data)

    # postprocess
    if global_processor and hasattr(global_processor, 'postprocess_raydata'):
        results = global_processor.postprocess_raydata(results, input_params)
    if global_processor and hasattr(global_processor, 'postprocess_pandas'):
        data_size = data.count()
        results = global_processor.postprocess_pandas(results.to_pandas(limit=data_size), input_params)
        results = ray.data.from_pandas(results)

    # get the write method
    write_method = getattr(results, FILE_WRITERS[resultformat])
    # write the results to 
    write_method(resultpath)

    #to-do: write meta_info to a json file in the target location; need to discuss
    #mf = manifest.load_manifest(artfacts_dir)
    #meta_info = mf.meta_info

if __name__ == "__main__":
    argParser = argparse.ArgumentParser()
    argParser.add_argument( "--sourcepath", type=str, required=True, help="file location; can be a local folder/file or S3 path")
    argParser.add_argument( "--sourceformat", type=manifest.SourceFileFormats, required=True, help="choose one from the following: ['csv', 'parquet', 'json', 'numpy', 'text', 'image']")
    argParser.add_argument("--resultpath", type=str, required=True, help="where to save the output")
    argParser.add_argument("--resultformat", type=manifest.ResultFileFormats, required=True, help="choose one from the following: ['csv', 'parquet', 'json', 'numpy']")
    argParser.add_argument("--suppresswarnings", action=argparse.BooleanOptionalAction, help="suppress warnings")
    args = argParser.parse_args()
    start_job(args.sourcepath,args.resultpath,args.sourceformat,args.resultformat,args.suppresswarnings)