from ray.train.predictor import Predictor
from ray.air.data_batch_type import DataBatchType
import numpy as np

import warnings
#import ecs.utils as utils

from mlflow.pyfunc import load_model


class BasePredictor(Predictor):
    """ 
    This is the core of the framework. It dynamically create an object based on custome application.py in init method;
    custom_predict gets invoked by the batch predictor during inferencing.
    """
    def __init__(self, input_params):
        super().__init__()
        if input_params['SUPPRESS_WARNINGS']:
            warnings.simplefilter('ignore')
        self.model_dir = input_params['MODEL_DIR']
        #self.manifest = utils.load_manifest(f'{self.model_dir}/artifacts')
        self.model = load_model(self.model_dir)
    

    def _predict_pandas(self, batch: DataBatchType) -> DataBatchType:
        result = self.model.predict(batch)
        if isinstance(result, np.ndarray) and len(result.shape) == 1:
            result = {'data': result}
        return result
    

    def _predict_numpy(self, batch: DataBatchType) -> DataBatchType:
        result = self.model.predict(batch)
        if isinstance(result, np.ndarray) and len(result.shape) == 1:
            result = {'data': result}
        return result

    @classmethod
    def from_checkpoint(cls, checkpoint, **kwargs):
        return BasePredictor(checkpoint.to_dict())
    