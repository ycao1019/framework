from pydantic import BaseModel, Field
from typing import Optional, Dict
from enum import Enum

class SourceFileFormats(str, Enum):
    csv = 'csv'
    parquet = 'parquet'
    json = 'json'
    numpy = 'numpy'
    text = 'text'
    image = 'image'


class ResultFileFormats(str, Enum):
    csv = 'csv'
    parquet = 'parquet'
    json = 'json'
    numpy = 'numpy'


class DeployConfig(BaseModel, extra='forbid'):
    
    project_name: str = Field(..., description="project name, also used for git repo and docker image generation, should be unique under mlflow registered models")
    env_vars: Optional[Dict] = Field({}, description="env vars to inject in the docker image")


class Stage(str, Enum):
    preprocess = 'preprocess'
    predict = 'predict'
    postprocess = 'postprocess'


class TestConfig(BaseModel, extra='forbid'):

    stage: Stage = Field(Stage.postprocess, description="debug different stages: preprocess, predict, postprocess")
    feature_data: str
    feature_format: SourceFileFormats
    target_data: Optional[str]
    target_format: Optional[ResultFileFormats]


class Manifest(BaseModel):
    deploy_config: DeployConfig
    input_params: Optional[Dict] = Field({}, description="the params to pass to pyclass.__init__()")
    meta_info: Optional[Dict] = None
    test_config: Optional[TestConfig]