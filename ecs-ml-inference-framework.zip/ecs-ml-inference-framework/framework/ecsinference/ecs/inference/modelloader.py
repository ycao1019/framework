from abc import ABC, abstractmethod

from mlflow.pyfunc import PythonModel
from ecs.utils import load_manifest
from ecs.utils import files_merge,file_decompress,delete_folder

import os
import logging


class BaseApplication(PythonModel, ABC):

    def load_context(self, context):
        logging.getLogger("mlflow").debug(context)
        manifest_path = context.artifacts['manifest']
        manifest = load_manifest(manifest_path)
        self.input_params = manifest.input_params
        # inject env vars if not
        env_vars = manifest.deploy_config.env_vars
        for k,v in env_vars.items():
            if k not in os.environ:
                os.environ[k] = v

        self.meta_info = manifest.meta_info
        if 'MODEL_DIR' in os.environ:
            self.models_path = os.path.join(os.environ['MODEL_DIR'], 'artifacts','models')
        else:
            if 'model_fragments' in context.artifacts:
                fragment_folder = context.artifacts['model_fragments']
                tmp_file = os.path.join('tmp','models.zip')
                model_folder = 'artifacts/models'
                files_merge(fragment_folder, tmp_file)
                file_decompress(tmp_file, model_folder)
                delete_folder('tmp')
                self.models_path = "artifacts/models"
            else:
                self.models_path = context.artifacts['models']
        self.load_model()

    def predict(self, context, payload):
        return self.make_prediction(payload)
    
    @abstractmethod
    def load_model(self):
        pass

    @abstractmethod
    def make_prediction(self, payload):
        pass


