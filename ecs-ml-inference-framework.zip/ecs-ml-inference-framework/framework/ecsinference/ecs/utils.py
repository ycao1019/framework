import importlib
from typing import Dict
from ecs.inference.manifest import Manifest
import json
import os
import shutil


FILE_CHUNK_SIZE = int(8 * 1024 * 1000)                   # default: 8Mb

def create_instance(module_name: str, class_name: str, input_params: Dict):
    target_class = load_object(load_module(module_name), class_name)
    return target_class(input_params)


def load_module(modulename):
    func = importlib.import_module(modulename)
    return func


def load_object(module, objname):
    return getattr(module, objname)


def load_manifest(path) -> Manifest:
    return Manifest(**load_json(path))

def load_json(path) -> dict:
    with open(path, 'r') as f:
        return json.load(f)    

def change_folder_name(src_path, folder_name):
    parent_folder = os.path.dirname(src_path)
    shutil.move(src_path, os.path.join(parent_folder,folder_name))


def is_file(file_path) -> bool:
    return os.path.exists(file_path) and os.path.isfile(file_path)

def is_folder(folder_path) -> bool:
    return os.path.exists(folder_path) and os.path.isdir(folder_path)


def replace_strings_in_file(file_path: str, string_dict: dict, target_path = None) -> str:
    assert is_file(file_path)
    with open(file_path, 'r') as ft:
        content = ft.read()
        for key in string_dict:
            content = content.replace(key, string_dict[key])
    if target_path:
        with open(target_path, "w") as target:
            target.write(content)        
    return content


def file_split(fromfile, todir, chunksize=FILE_CHUNK_SIZE): 
    if not os.path.exists(todir):                  # caller handles errors
        os.mkdir(todir)                            # make dir, read/write parts
    else:
        for fname in os.listdir(todir):            # delete any existing files
            os.remove(os.path.join(todir, fname)) 
    partnum = 0
    input = open(fromfile, 'rb')                   # use binary mode on Windows
    while 1:                                       # eof=empty string from read
        chunk = input.read(chunksize)              # get next part <= chunksize
        if not chunk: break
        partnum  = partnum+1
        filename = os.path.join(todir, ('part%04d' % partnum))
        fileobj  = open(filename, 'wb')
        fileobj.write(chunk)
        fileobj.close()                            # or simply open(  ).write(  )
    input.close()
    assert partnum <= 9999                         # join sort fails if 5 digits
    return partnum


readsize = 4096

def files_merge(fromdir, tofile):
    todir=os.path.dirname(tofile)
    if not is_folder(todir):
        os.makedirs(todir)
    with open(tofile, 'wb') as output:
        parts  = os.listdir(fromdir)
        parts.sort(  )
        for filename in parts:
            filepath = os.path.join(fromdir, filename)
            fileobj  = open(filepath, 'rb')
            while 1:
                filebytes = fileobj.read(readsize)
                if not filebytes: break
                output.write(filebytes)
            fileobj.close(  )

def dir_compress(fromdir, tofile, format='zip'):
    shutil.make_archive(tofile, format, fromdir)

def file_decompress(zipfile, todir, format='zip'):
    shutil.unpack_archive(zipfile, todir, format)

def delete_folder(dir):
    if is_folder(dir):
        shutil.rmtree(dir)