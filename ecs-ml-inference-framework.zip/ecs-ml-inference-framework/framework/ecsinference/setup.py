from setuptools import setup, find_packages

setup(
    author="Yan Cao",
    description="ECS Model Deployments Framework based on Ray and MLflow",
    name="ecsinference",
    packages=find_packages(include=["ecs", "ecs.*"]),
    version="0.3.0",
    install_requires=[
        "pytest>=7.0.0",
        "pandas>=2.0",
        "pydantic==1.10.11",
        "pyarrow>=12.0.1",
        "ray[default]==2.3.1",
        "mlflow>=2.5.0",
        "timeout-decorator",
        "PyYAML"
    ]
)