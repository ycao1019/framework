import os
import json

from termcolor import *
import colorama


class cliUtil:
    def __init__(self):
        colorama.init()
        self.p_count = 0


    def color_red(self, instr):
        outstr = colored(instr, "red")
        return outstr

    def color_cyan(self, instr):
        outstr = colored(instr, "light_cyan")        
        return outstr

    def color_blue(self, instr):
        outstr = colored(instr, "cyan")        
        return outstr

    def generate_json(self, root_dir):
        file_tree = {}
        for root, dirs, files in os.walk(root_dir):
            current_dir = file_tree
            path = root.split(os.sep)
            level = len(path) - len(root_dir.split(os.sep))
        
            for folder in path:
                # if folder and not folder.startswith('.') and not folder.startswith('_'):
                if not folder.startswith('.') and not folder.startswith('_'):                    
                    if folder not in current_dir:
                        current_dir[folder] = {}
                    current_dir = current_dir[folder]
            for file in files:
                if file and not file.startswith('.') and file not in current_dir:
                    current_dir[file] = "file"
                # current_dir[file] = "file"{}
        # print(file_tree)
        return file_tree    

    def print_directory_tree(self, json_data, printparm, indent_size=2):

        skiplevel       = printparm['printlevel']
        printfolderonly = printparm['printfloder']        
        printv          = printparm['printcomment'] 
        printline       = printparm['printline']        
        project_id      = printparm['projectid']        
        
      
        p_dict = {}
        self.p_count = 0
        def print_tree(node, indent_level=0):
            if isinstance(node, dict):
                for key, value in node.items():

                    if indent_level > skiplevel:
                        continue
                    value_str = str(value)
                    if value_str == "file":
                        folder_or_file = "file"
                    else:
                        folder_or_file = "folder"
                
                    prefix = " " * indent_size * indent_level
                    if folder_or_file == "folder":
                        if key == "projects":
                            c_key  = colored(key, "red") 
                        else:
                            if printfolderonly == "y" and indent_level == 1:    
                                self.p_count += 1
                                p_dict["project" + str(self.p_count)] = key
                            if printfolderonly == 'y' and indent_level == 2:    
                                p_dict["version" + str(self.p_count)] = key
                            c_key  = colored(key, "light_cyan") 
                        printparm["projectid"] = project_id         
                        printparm["key"] = key
                        printparm["value"] = value
                        v = self.mt_content(printparm)
                        if printline != "n":
                            print(f"{prefix} └── {c_key}  {v}".format(prefix, c_key, v))    

                    else:
                        if printfolderonly != 'y':
                            # printparm["projectid"] = project_id         
                            printparm["key"] = key
                            printparm["value"] = value
                            v = self.mt_content(printparm)
                            if printline != "n":
                                print(f"{prefix} ├── {key}  {v}".format(prefix, key, v) )


                    print_tree(value, indent_level + 1)
            elif node is None or node == "file":
                return
            else:
                raise ValueError("Invalid JSON data format. Expected dictionary or None.")

        file_tree = json.loads(json_data)
        print_tree(file_tree)
        return p_dict   

    def mt_content(self,  printparm):
        calltype     = printparm['printcomment']        

        if calltype =='n':
            return " "
        key = printparm['key']

        if key == "src":
            return " "
        
        if key == "projects":
            return " "       
        action       = printparm['action']        
        project_id   = printparm['projectid']  

        if action == "newproject":
            if key == project_id: 
                wl = len(key)
                filler = " " * (20 - wl)
                msg = filler + "-- New project ID: {0} as the current working foler name.".format(self.color_cyan("'" + project_id + "'"))
                return msg
            if key == "requirements.txt": 
                wl = len(key)
                filler = " " * (18 - wl)
                msg = filler + "-- add python dependencies required by your project."
                return msg
            if key == "workflow.ipynb": 
                wl = len(key)
                filler = " " * (18 - wl)
                msg = filler + "-- Use this script to help inference coding and image build."
                return msg
            if key == "manifest.json": 
                wl = len(key)
                filler = " " * (18 - wl)
                msg = filler + "-- {0} needs to be modified for your project need.".format(self.color_cyan("'" + key + "'"))
                return msg
            if key == "models": 
                wl = len(key)
                filler = " " * (18 - wl)
                msg = filler + "-- ML model files need to be copied here"
                return msg
            if key == "scripts": 
                wl = len(key)
                filler = " " * (18 - wl)
                msg = filler + "-- It is for the CLI program, and don't worry about this folder."
                return msg                
            if key == "application.py": 
                wl = len(key)
                filler = " " * (16 - wl)
                msg = filler + "-- {0} needs to be modified for your project need.".format(self.color_cyan("'" + key + "'"))
                return msg
            if key == "tests": 
                wl = len(key)
                filler = " " * (18 - wl)
                msg = filler + "-- the test csv or json file need to be placed in this folder."
                return msg
        
        if action == "status":
            if key == project_id: 
                wl = len(key)
                filler = " " * (20 - wl)
                msg = filler + "-- New project ID: {0} as the current working foler name.".format(self.color_cyan("'" + project_id + "'"))
                return msg
            if key == "manifest.json": 
                wl = len(key)
                filler = " " * (18 - wl)
                msg = filler + "-- {0} needs to be modified for your project need.".format(self.color_cyan("'" + key + "'"))
                return msg
            if key == "models": 
                wl = len(key)
                filler = " " * (18 - wl)
                msg = filler + "-- ML model files need to be copied here"
                return msg
            if key == "scripts": 
                wl = len(key)
                filler = " " * (18 - wl)
                msg = filler + "-- It is for the CLI program, and don't worry about this folder."
                return msg                
            if key == "application.py": 
                wl = len(key)
                filler = " " * (16 - wl)
                msg = filler + "-- {0} needs to be modified for your project need.".format(self.color_cyan("'" + key + "'"))
                return msg
            if key == "tests": 
                wl = len(key)
                filler = " " * (18 - wl)
                msg = filler + "-- the test csv or json file need to be placed in this folder."
                return msg


    def print_menu(self, menu_message, options, input_msg):
        """Prints a CLI menu with the given message and options."""
        line_width = 70
        option_width = 8
        description_width = line_width - option_width - 2  # Subtract 2 for spacing
        line_separator = self.color_blue("-" * line_width)
        print(line_separator)
        print(menu_message.center(line_width))
        print(line_separator)
        for index, option in enumerate(options, start=1):
            name, description = option
            option_text = f"{index}. {name}"
            formatted_option = f"{option_text:{option_width}}"
            formatted_description = f"{description:{description_width}}"
            print(f"{formatted_option} {formatted_description}")
        print(line_separator)
        print()

        user_input = input(input_msg)
        while user_input.lower() not in ['c', 'q']:
            print("")
            print(self.invalid_msg)
            user_input = input(input_msg )

        userinput = user_input.lower()
        if userinput == 'q':
            print("Exiting...")
            # Add any additional 
        return userinput
     
    def clear_screen(self):
        if os.name == "nt":
            os.system("cls")
        else:
            os.system("clear")

    def read_help_json(self):
        with open( self.root + '/auxiliary-cli/config/help.json', 'r') as f:
            data = json.load(f)
        return data

    def status_json(self, action, key):
        with open( self.root + '/auxiliary-cli/config/status.json', 'r') as f:
            data = json.load(f)

        if action == "r":
            out_data = data["current_project"]["current_project_id"]
        
        return out_data

    def update_status(self, project_id):
        from datetime import datetime
        with open( self.root + '/auxiliary-cli/config/status.json', 'r') as f:
            data = json.load(f)

        # Get the local username
        username = os.getlogin()

        current_datetime = datetime.now()
        datetime_str = current_datetime.isoformat()

        data["current_project"]["current_project_id"] = project_id
        data["current_project"]["project_start_date"] = datetime_str
        data["userid"] = username
       
        with open(self.root + '/auxiliary-cli/config/status.json', 'w') as f:
            json.dump(data, f)

    def is_folder_empty(folder_path):
        # Get the list of files and directories in the given folder
        items = os.listdir(folder_path)

        # Check if the folder is empty or does not have any .ipynb files
        if len(items) == 0 or not any(item.endswith('.ipynb') for item in items):
            return True
        else:
            return False

    def check_artifacts(self, project_id, root):
        result = {}
        code = 0

        manifest_path = os.path.join(root, 'projects', project_id,'manifest.json')
        if not os.path.isfile(manifest_path):
            result["project manifest file"] = "missing manifest file"
            return result, code

        with open(manifest_path, 'r') as f:
            manifest = json.load(f)

        feature_data = manifest['test_config']['feature_data']
        feature_format = manifest['test_config']['feature_format']
        feature_data_path = os.path.join(root, 'projects', project_id,'tests', feature_data)
        if not os.path.isfile(feature_data_path):
            result["project test data file:      "] = "missing feature data file"
            code = 404
            return result, code 
        else:
            code = 0
            return result, code
        """
    
        # Check if feature_data file exists
        feature_data_path = os.path.join(directory_path, feature_data)
        if os.path.isfile(feature_data_path):
            print(f"{feature_data} exists in the directory.")
            if feature_format in feature_data:
                print(f"{feature_data} format matches feature_format.")
            else:
                print(f"{feature_data} format does not match feature_format.")
        else:
            print(f"{feature_data} does not exist in the directory.")

        # Check if target_data file exists
        target_data = manifest['test_config']['target_data']
        target_data_path = os.path.join(directory_path, target_data)
        if os.path.isfile(target_data_path):
            print(f"{target_data} exists in the directory.")
        else:
            print(f"{target_data} does not exist in the directory.")
        """
