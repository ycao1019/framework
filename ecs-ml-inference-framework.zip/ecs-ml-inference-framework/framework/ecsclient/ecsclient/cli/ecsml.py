import os
import sys
from ecsclient.cli.workDir import workSpace
'''
if os.environ['CONDA_DEFAULT_ENV'] != "ray_env":
    print("It appears that you may not have installed the necessary running evironment.")
    print("Please read the readme.md at root folder, setup conda 'ray_evn' environment and run 'conda activate ray_env'.")
    print("------------------------------------------")
    os._exit(0)

'''

try: 
    import typer
    from typing import Optional
    from termcolor import *
    import colorama
except ImportError:
    print ("")  
    print ("please run 'pip install -r cli_requirements.txt' before running this application.")  
    print ("If you are running from the ECSML executable, it may be necessary to recomplie it" )
    print ("using PYINSTALLER after installing the environment.")  
    os._exit(0)      


app = typer.Typer()
colorama.init()    

@app.command()
def help():
    """type python artmgr.py help to get subcommand help infomation"""
    print("")
    usage = colored("Usage: ", "light_cyan")
    print(usage + "ecsml SUBCOMMAND [ARGS]...")

    leftb  = colored("[", "cyan") 
    rightb = colored("]", "cyan")     
    four_blank = " " * 4
    # with open('./auxiliary-cli/config/help.json', 'r') as f:
    #    data = json.load(f)
    wd = workSpace()
    data = wd.read_help_json()        

    for firstlevel, secondlevel in data.items():
        print(" ")
        ctext = colored(firstlevel, "cyan")   
        print(leftb + ctext + rightb)
        for key, value in secondlevel.items():
            k_len = len(key)
            suffix = " " * (23 - k_len)
            ctext = colored(key, "light_cyan")   
            print(four_blank + ctext + suffix + value)

@app.command()
def test(name: Optional[str] = typer.Argument(None)):
    """enter project name and version number"""
    # typer.echo(f"Goodbye, {name}!")
    wd = workSpace()
    wd.test_applicationpy(name)

@app.command()
def imagebuild(name: Optional[str] = typer.Argument(None)):
    """build docker image"""
    wd = workSpace()
    wd.build_image(name)

@app.command()
def imagescan(name: Optional[str] = typer.Argument(None)):
    """build docker image"""
    wd = workSpace()
    wd.image_scan(name)

@app.command()
def commit(name: Optional[str] = typer.Argument(None)):
    """commit the project to git repository"""
    wd = workSpace()
    wd.commit(name)

@app.command()
def status():
    """show the status of current project"""
    ws = workSpace()
    ws.showstatus()

@app.command()
def modelregister(name: Optional[str] = typer.Argument(None)):
    """connect to MLflow"""    
    ws = workSpace()
    ws.register_model(name)

@app.command()
def new(name: Optional[str] = typer.Argument(None)):
    """create a new project working folder"""    
    ws = workSpace()
    ws.new_project(name)

@app.command()
def switch(name: Optional[str] = typer.Argument(None)):
    """switch project and save current project information"""
    ws = workSpace()
    ws.switchproject(name)

@app.command()
def list(name: Optional[str] = typer.Argument(None)):
    """list projects"""
    ws = workSpace()
    ws.list_project()

@app.command()
def current(name: Optional[str] = typer.Argument(None)):
    ws = workSpace()
    ws.current_project()

def check_argv():
    
    if len(sys.argv) > 1:
        name = sys.argv[1]
        # with open('auxiliary-cli/config/help.json', 'r') as f:
        #    data = json.load(f)
        wd = workSpace()
        data = wd.read_help_json()        

        for firstlevel, secondlevel in data.items():
            for key, value in secondlevel.items():
                if name == key:
                    return
        cname = "'" + name + "'"
        cname = colored(cname, "light_cyan") 
        msgc = colored(" 'artifact_mgr.py help' ", "light_cyan")
        msg  = colored("  Unknown subcommand: ", "white") 
        print(msg + cname + ".")
        print("  Type" + msgc + "for usage.")
        os._exit(0)
    else:
        print("")
        print(colored("Missing subcommand. ", "red"))
        help()
        os._exit(0)

if __name__ == "__main__":
    check_argv()
    app() 
    


    