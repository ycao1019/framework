from pydantic import BaseModel, Field
from typing import Optional

class ImageInfo(BaseModel):
    project_name: str = Field(..., description="project name should be unique under mlflow registered models")
    image_name: str = Field(..., description="image name, should be unique in ECR")
    image_version: int = Field(..., description="image version, maintained by mlflow")
    framework_version: Optional[str] = Field('', description="version of ecsinference package")
    creation_time: str = Field(..., description="the time when the local image is created")
    author: str = Field(..., description="the author of the image")
    success: Optional[bool] = Field(False, description="whether the image is successfully built")