from setuptools import setup, find_packages
import ecsclient
setup(
    author="Yan Cao",
    description="ECS Model Deployments CLI based on ECS Model Deployments Framework",
    name="ecsclient",
    packages=find_packages(include=["ecsclient", "ecsclient.*"]),
    version="0.1.0",
    install_requires=[
        "ecsinference==0.3.0",
        "typer",
        "termcolor",
        "colorama",
        "PyYAML",
        "nbformat",
        "docker>=6.1.0",
        "GitPython>=3.1.18"
    ]
)