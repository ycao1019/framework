from ecs.inference.modelloader import BaseApplication


class Application(BaseApplication):
    """ """

    # implementing abstract method
    def load_model(self):
        """There are some attributes already set up under self:
        self.input_params: dict from manifest.json -> input_params
        self.meta_info: dict from manifest.json -> meta_info
        self.models_path: directory where the model artifacts are saved
        
        Please add your custom logic here to load the model artifacts, e.g.
        self.model = joblib.load(f'{self.models_path}/model.pkl')
        """

    # implementing abstract method
    def make_prediction(self, payload):
        """Add your custom logic here to make prediction.

        Parameters
        ----------
        payload :
            treat the payload as a pd.dataframe; keep in mind that it is not the whole dataset but a batch of it.
            Ray splits the workload into batches and run make_prediction() in parallel.

        Returns
        -------
            in most cases, the returned object should be a pd.dataframe; 
            if there is only one column, it can be a one-dimensional np.array.
        """
        return payload



class GlobalProcessor:
    """ This is a global processor that will be applied to the WHOLE dataset before and after prediction.
    When you want to get a new column based on sorting of a column, you will need to implement it here.
    This class is optional. If you don't need global processing, just delete it. 
    There are 2 sets of methods: preprocess and postprocess. Under each set, there are 2 methods which take
    different input types: ray.data.Dataset and pandas.dataframe.

    preprocess_raydata() and postprocess_raydata() should be faster due to ray's distributed calculation but 
    knowledge of ray.data is required.
    preprocess_pandas() and postprocess_pandas() are easier to use but slower, especially when the dataset 
    is large.
    If the dataset is extremely large (like billion level), pandas methods are not recommended because all the 
    computations happen in the header node of the ray cluster and it may exceed the hardware limit.

    REMIND: only keep the method you implemented. For example, if you only need postprocessing_pandas, delete all the 
    other methods in the class.
    """

    from ray.data import Dataset
    import pandas as pd

    @classmethod
    def preprocess_raydata(cls, dataset: Dataset, input_params: dict = None) -> Dataset:
        """ add your custom logic here to preprocess the whole dataset before prediction.

        Parameters
        ----------
        dataset: Dataset :
            WHOLE dataset

        input_params: dict = None :
            input_params from manifest.json
        
        Returns
        -------
            the preprocessed dataset
        """
        return dataset

    @classmethod
    def postprocess_raydata(cls, dataset: Dataset, input_params: dict = None) -> Dataset:
        """ add your custom logic here to postprocess the whole dataset after prediction.
        Parameters
        ----------
        dataset: Dataset :
            WHOLE dataset
        
        input_params: dict = None :
            input_params from manifest.json
        
        Returns
        -------
            the postprocessed dataset
        """
        return dataset

    @classmethod
    def preprocess_pandas(cls, dataset: pd.DataFrame, input_params: dict = None) -> pd.DataFrame:
        """ add your custom logic here to preprocess the whole dataset before prediction.

        Parameters
        ----------
        dataset: Dataset :
            WHOLE dataset

        input_params: dict = None :
            input_params from manifest.json
        
        Returns
        -------
            the preprocessed dataset
        """
        return dataset

    @classmethod
    def postprocess_pandas(cls, dataset: pd.DataFrame, input_params: dict = None) -> pd.DataFrame:
        """ add your custom logic here to postprocess the whole dataset after prediction.

        Parameters
        ----------
        dataset: Dataset :
            WHOLE dataset
        
        input_params: dict = None :
            input_params from manifest.json
        
        Returns
        -------
            the postprocessed dataset
        """
        return dataset