#!/bin/zsh
conda activate base
conda install python=3.10 ipykernel --yes
conda install grpcio=1.43.0 -c conda-forge --yes

#pip install mlflow
#pip install -U "ray[default]"
pip install -e ./framework/ecsinference
pip install -e ./framework/ecsclient
pip install requests-auth-aws-sigv4

sed "s#{{DIR_NAME}}#$(pwd)#" ./templates/ecsml_template > bin/ecsml.sh
chmod +x bin/ecsml.sh
ln bin/ecsml.sh ${CONDA_PREFIX}/bin/ecsml 