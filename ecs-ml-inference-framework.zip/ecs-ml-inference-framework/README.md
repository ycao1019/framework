# ecs-inference-framework
This framework uses Mlflow Tracking Server to manage, track, tag the model artifacts,  and uses Ray as the backend inferencing engine to do batch inferencing very efficiently. The end users are data scientists (DS). A set of CLI commands help DS to do the following operations.

- initialize a new project
- switch to an existing project
- install dependencies
- inference coding and unit testing
- register model to MLflow Server
- build image
- scan image

## Preperations before anything
1. User has the trained model files locally.
2. User has the test data ready; the user needs to save the input data into one csv file and the output results as another csv file.
3. Custom python files used in training or inferencing if any.
4. miniconda or anaconda installed (miniconda recommended )

## installation steps
### miniconda and Jupyter installation
If you already have minicodan or anaconda installed, please skip this step.

[Install miniconda](https://docs.conda.io/en/latest/miniconda.html)

Install Jupyter:
```
pip install notebook
```

### install ecsml command and its dependencies
```
# under the repo root directory, run the command below:
source setup.sh
```

## Useful Resources
[Framework Introduction](https://experianecs.atlassian.net/wiki/spaces/DCOE/pages/485524367/MLFlow-Ray-based+ML+Model+Deployment+Framework)
[Jupyter Notebook Script](./basic_workflow.ipynb)