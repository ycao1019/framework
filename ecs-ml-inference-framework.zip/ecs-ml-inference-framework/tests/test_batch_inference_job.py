import pytest
import pandas as pd
import numpy as np
import ray.data as raydata
from ecs.inference.jobmanager import start_job
from ecs.utils import load_manifest, delete_folder
from ecs.inference.manifest import ResultFileFormats

import os
import glob

MODEL_DIR = os.environ["MODEL_DIR"]

def get_last_file_in_folder(path, suffix):
    files = glob.glob(f"{path}/*.{suffix}")
    if len(files) == 0:
        return None
    files.sort(key=os.path.getmtime)
    return files[-1]

def test_batch_inferencing():
    mf = load_manifest(f'{MODEL_DIR}/artifacts/manifest.json')
    test_config = mf.test_config
    if not test_config:
        return
    
    validate_results = False
    if test_config.target_data:
        assert test_config.target_format is not None
        validate_results = True
    resultpath=f'{MODEL_DIR}/artifacts/tests/results'
    if os.path.exists(resultpath):
        delete_folder(resultpath)
    start_job(sourcepath=f'{MODEL_DIR}/artifacts/tests/{test_config.feature_data}', resultpath=resultpath, sourceformat=test_config.feature_format, resultformat=test_config.target_format, suppresswarnings=True)
    
    target_file = test_config.target_data
    result_data, target_data = None, None
    if validate_results:
        assert os.path.exists(resultpath), f'No result file found under path: {resultpath}'
        if test_config.target_format == ResultFileFormats.csv:
            result_file = get_last_file_in_folder(resultpath, 'csv')
            assert result_file is not None, 'No csv result file found under path: {resultpath}'
            result_data = raydata.read_csv(resultpath).to_pandas()
            target_data = pd.read_csv(f'{MODEL_DIR}/artifacts/tests/{target_file}')
        elif test_config.target_format == ResultFileFormats.json:
            result_file = get_last_file_in_folder(resultpath, 'json')
            assert result_file is not None, 'No json result file found under path: {resultpath}'
            result_data = raydata.read_json(resultpath).to_pandas()
            target_data = pd.read_json(f'{MODEL_DIR}/artifacts/tests/{target_file}', orient='records', lines=True)
        elif test_config.target_format == ResultFileFormats.parquet:
            result_file = get_last_file_in_folder(resultpath, 'parquet')
            assert result_file is not None, 'No parquet result file found under path: {resultpath}'
            result_data = raydata.read_parquet(resultpath).to_pandas()
            target_data = pd.read_parquet(f'{MODEL_DIR}/artifacts/tests/{target_file}')
        else:
            result_file = get_last_file_in_folder(resultpath, 'npy')
            assert result_file is not None, 'No npy result file found under path: {resultpath}'
            result_data = raydata.read_numpy(resultpath).to_pandas().values
            target_data = np.load(f'{MODEL_DIR}/artifacts/tests/{target_file}')        

        if test_config.target_format == ResultFileFormats.numpy:
            assert result_data == pytest.approx(target_data)

        else:
            print(target_data.dtypes)
            print(result_data.dtypes)
            assert target_data.shape == result_data.shape, f"target_data shape: {target_data.shape} is different from result_data shape: {result_data.shape}"
            # if returned results only have one column, ignore the column name and just compare the values
            if target_data.shape[1] == 1:
                if target_data.dtypes.iloc[0] == "object":
                    assert all(target_data.values == result_data.values)
                else:
                    assert all(target_data.values == pytest.approx(result_data.values))
            else:
                assert all(target_data.columns.sort_values() == result_data.columns.sort_values()), "target_data and result_data don't have same column names"
                string_cols, num_cols = [], []
                for columnname in target_data.dtypes.index:
                    if target_data.dtypes.loc[columnname] == 'object':
                        string_cols.append(columnname)
                    else:
                        num_cols.append(columnname) 
                if string_cols:
                    result = (target_data[string_cols].values == result_data[string_cols].values)
                    result = np.apply_along_axis(all, 1, result)
                    result = np.argwhere(result==False).reshape([-1])
                    assert len(result) == 0, (
                        f"some values in these columns {string_cols} at these indices {result.tolist()} don't match."
                    )
                if num_cols:
                    pd.testing.assert_frame_equal(target_data[num_cols], result_data[num_cols], atol = 0.000001, check_dtype=False)
