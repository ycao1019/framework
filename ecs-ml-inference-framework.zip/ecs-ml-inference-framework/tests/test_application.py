import pytest
import pandas as pd
import numpy as np

from ecs.utils import load_manifest, load_module, load_object
from ecs.inference.manifest import ResultFileFormats, SourceFileFormats

import os
import sys
from mlflow.pyfunc import PythonModelContext
import ray.data as raydata

PROJECT_DIR = os.path.join(os.environ['INFERENCE_BASE_DIR'], f"projects/{os.environ['WORKING_PROJECT']}")

FILE_READERS = {
    'csv': pd.read_csv,
    'parquet': pd.read_parquet
}

@pytest.fixture(scope="session")
def save(pytestconfig):
    return pytestconfig.getoption("save")


def test_Application(save):
    os.chdir(PROJECT_DIR)
    print(os.curdir)
    mf = load_manifest('manifest.json')
    test_config = mf.test_config
    if not test_config:
        return
    
    custom_code_path = 'src'
    if os.path.exists(custom_code_path):
        sys.path.append(custom_code_path)

    # load global processor
    try:
        global_processor = load_object(load_module("application"), "GlobalProcessor")
    except:
        global_processor = None

    from application import Application
    app = Application()
    artifacts={'manifest':'manifest.json', 'test_data': 'tests', 'models': 'models'}
    context = PythonModelContext(artifacts)
    app.load_context(context)
    validate_results = False
    if test_config.target_data:
        assert test_config.target_format is not None
        validate_results = True
    
    test_data, target_data = None, None
    try:
        if test_config.feature_format in [SourceFileFormats.csv,SourceFileFormats.parquet]:
            test_data = FILE_READERS[test_config.feature_format](f'tests/{test_config.feature_data}')
        elif test_config.feature_format == SourceFileFormats.json:
            test_data = pd.read_json(f'tests/{test_config.feature_data}', orient='records', lines=True)
        else:
            raise ValueError('input data format is not supported in unit testing')
        if validate_results:
            if test_config.target_format == ResultFileFormats.csv:
                target_data = pd.read_csv(f'tests/{test_config.target_data}')
            elif test_config.target_format == ResultFileFormats.json:
                target_data = pd.read_json(f'tests/{test_config.target_file}', orient='records', lines=True)
            elif test_config.target_format == ResultFileFormats.parquet:
                target_data = pd.read_parquet(f'tests/{test_config.target_data}')
            else:
                target_data = np.load(f'tests/{test_config.target_data}')      
    except ValueError as e:
        pytest.fail(e)

    # preprocess
    if global_processor and hasattr(global_processor, "preprocess_raydata"):
        data_counts = test_data.shape[0]
        test_data = raydata.from_pandas(test_data)
        test_data = global_processor.preprocess_raydata(test_data, app.input_params)
        test_data = test_data.to_pandas(limit=data_counts)
    if global_processor and hasattr(global_processor, "preprocess_pandas"):
        test_data = global_processor.preprocess_pandas(test_data, app.input_params)

    # predict
    result_data = app.predict(None, test_data)

    # postprocess
    if global_processor and hasattr(global_processor, "postprocess_raydata"):
        data_counts = result_data.shape[0]
        result_data = raydata.from_pandas(result_data)
        result_data = global_processor.postprocess_raydata(result_data, app.input_params)
        result_data = result_data.to_pandas(limit=data_counts)
    if global_processor and hasattr(global_processor, "postprocess_pandas"):
        result_data = global_processor.postprocess_pandas(result_data, app.input_params)
    
    if save=='y':
        from datetime import datetime
        now = datetime.now()
        file_name = "prediction_" + now.strftime("%Y-%m-%d-%H-%M-%S")
        if isinstance(result_data, np.ndarray):
            if result_data.ndim==1:
                result_data = pd.DataFrame({"data": result_data})
            else:
                cols = [f'col_{i}' for i in range(result_data.shape[1])]
                result_data = pd.DataFrame(result_data, columns=cols)
        result_data.to_csv(f'tests/{file_name}.csv', index=False)

    if validate_results:
        if test_config.target_format == ResultFileFormats.numpy:
            assert result_data == pytest.approx(target_data)

        else:
            if isinstance(result_data, np.ndarray) and result_data.ndim==1:
                result_data=result_data.reshape([-1,1])
            assert target_data.shape == result_data.shape, f"target_data shape: {target_data.shape} is different from result_data shape: {result_data.shape}"
            if isinstance(target_data, pd.DataFrame) and isinstance(result_data, np.ndarray):
                result_data = pd.DataFrame(result_data, columns=target_data.columns)

            # if returned results only have one column, ignore the column name and just compare the values
            if target_data.shape[1] == 1:
                if target_data.dtypes.iloc[0] == "object":
                    assert all(target_data.values == result_data.values)
                else:
                    assert all(target_data.values == pytest.approx(result_data.values))
            else:
                assert all(target_data.columns.sort_values() == result_data.columns.sort_values()), "target_data and result_data don't have same column names"
                string_cols, num_cols = [], []
                for columnname in target_data.dtypes.index:
                    if target_data.dtypes.loc[columnname] == 'object':
                        string_cols.append(columnname)
                    else:
                        num_cols.append(columnname) 
                if string_cols:
                    result = (target_data[string_cols].values == result_data[string_cols].values)
                    result = np.apply_along_axis(all, 1, result)
                    result = np.argwhere(result==False).reshape([-1])
                    assert len(result) == 0, (
                        f"some values in these columns {string_cols} at some indices don't match."
                        f"{result.tolist()}"
                    )
                if num_cols:
                    # cast the result columns the same type as target columns
                    for col in num_cols:
                        result_data[col] = result_data[col].astype(target_data[col].dtypes)
                    pd.testing.assert_frame_equal(target_data[num_cols], result_data[num_cols], atol = 0.000001, check_dtype=False)
