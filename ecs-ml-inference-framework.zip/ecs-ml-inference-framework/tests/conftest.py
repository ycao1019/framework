def pytest_addoption(parser):
    parser.addoption("--save", action="store", default='n')